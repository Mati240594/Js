let myNumber = parseInt(prompt("Ingresá tú número "));
for(let i=0; i<= 10;i++ ){
    let resultado = (myNumber*i)/(myNumber+i*2);
    alert("El resultado de la ecuación es" + resultado);
}

